""" Made by osga21 @ GBATemp for use with the homebrew app picroxx!
    You can copy whatever you want, but the code is shit so I
    would advise you not to, but I don't care what you do with this
"""



from Tkinter import *
import Tkinter
import tkMessageBox

irow1= ['"."','"."','"."','"."','"."']
irow2= ['"."','"."','"."','"."','"."']
irow3= ['"."','"."','"."','"."','"."']
irow4= ['"."','"."','"."','"."','"."']
irow5= ['"."','"."','"."','"."','"."']

def checkboxes():
    def check11():
        if (var11.get()):
            irow1[0]='"O"'
    def check12():
        if (var12.get()):
            irow1[1]='"O"'
    def check13():
        if (var13.get()):
            irow1[2]='"O"'
    def check14():
        if (var14.get()):
            irow1[3]='"O"'
    def check15():
        if (var15.get()):
            irow1[4]='"O"'

    def check21():
        if (var21.get()):
            irow2[0]='"O"'
    def check22():
        if (var22.get()):
            irow2[1]='"O"'
    def check23():
        if (var23.get()):
            irow2[2]='"O"'
    def check24():
        if (var24.get()):
            irow2[3]='"O"'
    def check25():
        if (var25.get()):
            irow2[4]='"O"'

    def check31():
        if (var31.get()):
            irow3[0]='"O"'
    def check32():
        if (var32.get()):
            irow3[1]='"O"'
    def check33():
        if (var33.get()):
            irow3[2]='"O"'
    def check34():
        if (var34.get()):
            irow3[3]='"O"'
    def check35():
        if (var35.get()):
            irow3[4]='"O"'

    def check41():
        if (var41.get()):
            irow4[0]='"O"'
    def check42():
        if (var42.get()):
            irow4[1]='"O"'
    def check43():
        if (var43.get()):
            irow4[2]='"O"'
    def check44():
        if (var44.get()):
            irow4[3]='"O"'
    def check45():
        if (var45.get()):
            irow4[4]='"O"'

    def check51():
        if (var51.get()):
            irow5[0]='"O"'
    def check52():
        if (var52.get()):
            irow5[1]='"O"'
    def check53():
        if (var53.get()):
            irow5[2]='"O"'
    def check54():
        if (var54.get()):
            irow5[3]='"O"'
    def check55():
        if (var55.get()):
            irow5[4]='"O"'

    check11()
    check12()
    check13()
    check14()
    check15()
    check21()
    check22()
    check23()
    check24()
    check25()
    check31()
    check32()
    check33()
    check34()
    check35()
    check41()
    check42()
    check43()
    check44()
    check45()
    check51()
    check52()
    check53()
    check54()
    check55()

    rowstr1=''.join(irow1)
    rowstr1= ', '.join([rowstr1[i:i+3] for i in range(0, len(rowstr1), 3)])
    rowstr1f="{"+rowstr1+"}"
    rowstr2=''.join(irow2)
    rowstr2= ', '.join([rowstr2[i:i+3] for i in range(0, len(rowstr2), 3)])
    rowstr2f="{"+rowstr2+"}"
    rowstr3=''.join(irow3)
    rowstr3= ', '.join([rowstr3[i:i+3] for i in range(0, len(rowstr3), 3)])
    rowstr3f="{"+rowstr3+"}"
    rowstr4=''.join(irow4)
    rowstr4= ', '.join([rowstr4[i:i+3] for i in range(0, len(rowstr4), 3)])
    rowstr4f="{"+rowstr4+"}"
    rowstr5=''.join(irow5)
    rowstr5= ', '.join([rowstr5[i:i+3] for i in range(0, len(rowstr5), 3)])
    rowstr5f="{"+rowstr5+"}"

    return rowstr1f +"\n"+rowstr2f +"\n"+rowstr3f +"\n"+rowstr4f +"\n"+rowstr5f +"\n"





picwin=Tkinter.Tk()
var11=IntVar()
var12=IntVar()
var13=IntVar()
var14=IntVar()
var15=IntVar()

c11=Checkbutton(picwin, variable =var11).grid(row=0, column=0)
c12=Checkbutton(picwin, variable =var12).grid(row=0, column=1)
c13=Checkbutton(picwin, variable =var13).grid(row=0, column=2)
c14=Checkbutton(picwin, variable =var14).grid(row=0, column=3)
c15=Checkbutton(picwin, variable =var15).grid(row=0, column=4)

var21=IntVar()
var22=IntVar()
var23=IntVar()
var24=IntVar()
var25=IntVar()


c21=Checkbutton(picwin, variable =var21).grid(row=1, column=0)
c22=Checkbutton(picwin, variable =var22).grid(row=1, column=1)
c23=Checkbutton(picwin, variable =var23).grid(row=1, column=2)
c24=Checkbutton(picwin, variable =var24).grid(row=1, column=3)
c25=Checkbutton(picwin, variable =var25).grid(row=1, column=4)

var31=IntVar()
var32=IntVar()
var33=IntVar()
var34=IntVar()
var35=IntVar()


c31=Checkbutton(picwin, variable =var31).grid(row=2, column=0)
c32=Checkbutton(picwin, variable =var32).grid(row=2, column=1)
c33=Checkbutton(picwin, variable =var33).grid(row=2, column=2)
c34=Checkbutton(picwin, variable =var34).grid(row=2, column=3)
c35=Checkbutton(picwin, variable =var35).grid(row=2, column=4)

var41=IntVar()
var42=IntVar()
var43=IntVar()
var44=IntVar()
var45=IntVar()


c41=Checkbutton(picwin, variable =var41).grid(row=3, column=0)
c42=Checkbutton(picwin, variable =var42).grid(row=3, column=1)
c43=Checkbutton(picwin, variable =var43).grid(row=3, column=2)
c44=Checkbutton(picwin, variable =var44).grid(row=3, column=3)
c45=Checkbutton(picwin, variable =var45).grid(row=3, column=4)

var51=IntVar()
var52=IntVar()
var53=IntVar()
var54=IntVar()
var55=IntVar()


c51=Checkbutton(picwin, variable =var51).grid(row=4, column=0)
c52=Checkbutton(picwin, variable =var52).grid(row=4, column=1)
c53=Checkbutton(picwin, variable =var53).grid(row=4, column=2)
c54=Checkbutton(picwin, variable =var54).grid(row=4, column=3)
c55=Checkbutton(picwin, variable =var55).grid(row=4, column=4)



    

def popup():
    opwin=Tkinter.Tk()
    filenamelbl=Label(opwin,text= "File Name:").grid(row=5,sticky=W)
    fstr=StringVar()
    filenameentry=Entry(opwin,textvariable=fstr).grid(row=5,column=1)
    
    sizelbl=Label(opwin,text= "Gridsize:").grid(row=0,sticky=W)
    sizestr=StringVar()
    sizeentry=Entry(opwin,textvariable=sizestr).grid(row=0,column=1)
    
    modelbl=Label(opwin,text="Gamemode:").grid(row=1,sticky=W)
    modestr=StringVar()
    modeentry=Entry(opwin,textvariable=modestr).grid(row=1,column=1)
 
    lvllbl=Label(opwin,text="Level Number:").grid(row=2,sticky=W)
    lvlstr=StringVar()
    lvlentry=Entry(opwin,textvariable=lvlstr).grid(row=2,column=1)
       
    lettlbl=Label(opwin,text="Level Letter:").grid(row=3,sticky=W)
    letterstr=StringVar()
    lettentry=Entry(opwin,textvariable=letterstr).grid(row=3,column=1)


    #remove this later!!
    lettlbl=Label(opwin,text="Just press the button, the entry fields are broken!").grid(row=7,column=1)



    def picwriter():
        filename="wooba" + str(fstr.get())
        levelsize=str(sizestr.get())
        gamemode=str(modestr.get())
        levelnumb=str(lvlstr.get())
        levelletter=str(letterstr.get())

        lvldatawrite= "leveldata.gridsize = "+levelsize+"\n"+"leveldata.gamemode = "+'"'+gamemode+'"'+"\n"+"leveldata.number = "+levelnumb+"\n"+"leveldata.letter = "+'"'+levelletter+'"'
        print lvldatawrite

    def provpicwriter():
        with open("picroxxlvl.txt", "w") as outputfile:
            print checkboxes()
            outputfile.write(checkboxes())

        


    createbutt=Button(opwin,text= "Create Puzzle!", command=provpicwriter).grid(row=6)

    
    opwin.mainloop()





button2=Button(picwin, text="Create!", command=popup).grid(row=5,column=3)
picwin.title("PyPicroxx Maker")
picwin.resizable(width=FALSE, height=FALSE)
picwin.minsize(width=250, height=175)
picwin.mainloop()
    
  





