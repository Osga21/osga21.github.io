How to install:

Put ezfla_up.bin on the root of your SD card
and as you boot your GBA press the R button
until you see a blue screen. Wait for the install to complete
and you're done. You can now delete ezfla_up.bin from 
your sd card if you'd like



Made by osga21
osga21.github.io