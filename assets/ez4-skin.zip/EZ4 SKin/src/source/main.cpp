/* *****************************************************
  EZ4 skin replacer - last updated by libertyernie 2015-07-27
  ******************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PROG_NAME "EZ4skin.exe"
#define false 0
#define true 1

typedef unsigned char u8;
typedef unsigned int u32;

FILE *inp, *gba, *nds, *bak, *tex, *asc;       /* In and out FILE Streams to read/write data */
char * buf;  // file buffer
char text[2][40] = { }; // buffer for text replacement
int occur;

void usage()
{
printf("EZ4skin R8 - nds.bin and gba.bin\n");
printf("-----------------------------------\n");
printf("Invalid command line.\n");
printf("Usage:\t%s\n", PROG_NAME);
printf("-----------------------------------\n");
}

// check for the string "text" at position posi in buf
int checkString(int posi, char* text, int strsz)
{
    int i = 0;
    while (i < strsz)
    {
        if (buf[posi+i] != text[i]) return 0;
        i++;
    }
    return 1;
}

// find a specified occurance of a  string in the buffered file
// return the position the first character of string
int findString (long bufsz, char* text, int strsz, int occ)
{
    long pos = 0;
    int found = 0, count = 0;
    while (pos < bufsz)
    {
        if ((buf[pos] == text[0]) && (bufsz > (pos+strsz)))
        {
            found = checkString(pos, text, strsz);
            if (found == 1) count++;
            if (occ == count) return pos;
        }
        pos++;
    }
    return -1;
}

// clears the strings used in the string replace function
void clearStrings(void)
{
    int i = 0;
    while (i < 40)
    {
        text[0][i] = 0x0;
        text[1][i] = 0x0;
        i++;
    }
    return;
}

// gets the next string from the open file
int getNext (void)
{
    int countin = 0, count = 0; int occur2;
    char in = '\0';
    while (in != ';')
    {
        in = getc(tex);
        if (in == EOF) return -1;
        if (in == ';') {text[0][countin] = 0x0;}
        else {text[0][countin] = in; countin++;}
    }
    in = 'a';
    while ((in != ';'))
    {
        in = getc(tex);
        if (in == EOF) return -1;
        if (in == ';') {text[1][count] = 0x0;}
        else {text[1][count] = in; count++;}
    }
    occur = getc(tex)-0x30;
    occur2 = getc(tex);
    if (occur2 != '\n') // if the occurance is not a single digit but double digit
    {
        occur = (occur * 10)+(occur2-0x30);
        getc(tex);
//        printf("multi occur found: %d", occur);
    }
    if (countin != count) return -2;
    return countin;
}

// replaces the strings in buffer with strings from the file
void skinTexts(long bufsz)
{
    int fail = 0, good = 0, count, size, pos;
    while ((size = getNext()) != -1)
    {
        if (size == -2)
        {
            printf("*******string size mismatch line %d******\n", (fail+good+1));
            fail++;
        }
        else
        {
            pos =findString(bufsz, text[0], size, occur);
            if (pos == -1)
            {
                printf("*******string on line %d not found******\n", (fail+good+1));
                fail++; // if not found increment failed find
            }
            else
            {
//                printf("line %d found at %x\n", (fail+good+1), pos);
                count = 0;
                while (count < size) // copy the new string to the buffer
                {
                    buf[pos+count] = text[1][count];
                    count++;
                }
                good++;
                clearStrings();
            }
        }
    }
    printf("\n%d strings found, %d not replaced\n\n", (fail+good), fail);
    return;
}

void print_ascdat_character(const char* data) {
	printf("%s", "/--------\\\n");
	for (int i = 0; i < 12; i++) {
		char c = data[i];
		printf("%s", "|");
		for (int j = 0; j < 8; j++) {
			printf("%s", ((128 >> j) & c) ? "@" : " ");
		}
		printf("%s", "|\n");
	}
	printf("%s", "\\--------/\n");
}

int main(int argc, char *argv[])
{
    char tmp;
    long lSize, lSizegba, lSizends, count = 0, ret = 0;
    char names[5][13] = {"nds.bin","gba.bin","ezfla_up.bin", "ezfla_up.bak"};

  /* Error check the command line */
    if(argc > 2)
    {  
        usage();                  /* Display Usage Information on error */
        printf("\npress <enter> to quit...\n");
        fgetc(stdin);
        return 0;               /* Exit Program returning 0 - no error */
    }

  /* print welcome Info message */
    printf("EZ4skin - NDS and GBA skin replacer\n"
           "-----------------------------------\n");
    printf("EZ updater file: %s\n", names[2]);
    printf("backup updater : %s\n", names[3]);
    if (argv[1] != NULL) printf("Texts file     : %s\n", argv[1]);
    printf("GBA skin-ROM   : %s\n", names[1]);
    printf("NDS skin-GBFS  : %s\n\n", names[0]);

  /* Error Check File Streams and backup the updater*/
    if (( inp = fopen(names[2], "rb")) == NULL) // open EZ4 updater
    {
        printf("** Error opening ezfla_up.bin.\n");
        return 0;
    }
    else // if input opened OK, make a copy and re-open it as a new file
    {
        if (( bak = fopen(names[3], "wb")) == NULL) // open updated file
        {
            printf("** Error opening ezfla_up.bak.\n");
            fclose(inp);
            return 0;
        }

          // get the size of the updater
        fseek (inp , 0 , SEEK_END);
        lSize = ftell (inp);
        rewind (inp);

          // allocate memory to contain the updater file.
        buf = (char*) malloc (lSize);
        if (buf == NULL) 
        {
            printf("** Unable to allocate memory\n");
            fclose(inp);
            return 0;
        }

          // copy the updater file into the buffer.
        printf("reading %s into buffer\n", names[2]);
        fread (buf, 1, lSize, inp);
        fclose (inp);

          // write a backup of last updater
        printf("backing up %s to %s\n", names[2], names[3]);
        fwrite (buf, 1, lSize, bak);
        fclose(bak);
    }

    if (( nds = fopen(names[0], "rb")) == NULL) // NDS GBFS skin
    {
        printf("** Error opening %s.\n", names[0]);
        nds = NULL;
    }

    if (( gba = fopen(names[1], "rb")) == NULL) // GBA ROM
    {
        printf("** Error opening %s.\n", names[1]);
        fclose(inp);
        fclose(nds);
        free(buf);
        return 0;
    }

  // obtain other file sizes.
    if (nds)
    {
        fseek(nds, 0, SEEK_END);
        lSizends = ftell(nds);
        rewind(nds);
    }

    fseek (gba , 0 , SEEK_END);
    lSizegba = ftell (gba);
    rewind (gba);

    printf("\n---Finding GBA skin offset---\n");
  // find 1st occurence of \.shell\bmp followed by at least 5 null characters
    ret = findString(lSize, "\\.shell\\bmp\0\0\0\0\0", 16, 1);
    if (ret == -1) { printf("\nGBA skin not found in updater\n"); }
    else
    {
        printf("GBA skin found at offset: 0x%lx (%ld)\n", ret, ret);
      // advance gba.bin to 199608 (0x30000) since that is where rombuilder puts the skin by default
        rewind(gba);
        fseek (gba, 196608, SEEK_SET);
        count = 196608;
      // write GBA skin to buffer
        printf("reading %s and overwriting GBA skin in buffer\n", names[1]);
        while (count < lSizegba)
        {
            tmp=getc(gba);
            buf[ret] = tmp;
            ret++; count++;
        }
    }

  // if text file then skin texts
    if (argv[1] != NULL) 
    {
        printf("\n---Skinning texts---\n");
        if (( tex = fopen(argv[1], "r")) == NULL) // open texts file
        {
            printf("** Error opening %s\n",argv[1]);
            printf("Texts NOT skinned\n");
        }
        else 
        {
            skinTexts(lSize);
            fclose(tex);
        }
    }

    printf("\n---Finding NDS skin offset---\n");
  // find first occurance of PinEightGBFS
    ret = nds == NULL
        ? -1
        : findString(lSize, "PinEightGBFS", 12, 1);
    count = 0;
    if (ret == -1)
    {
        printf("\nGBFS not found in updater or nds.bin not found - writing GBA skin only\n");

		// find at sign (0x300)
		char to_find_atsign[12] = {
			0x00, 0x00, 0x70, 0x88,
			0x98, 0xA8, 0xA8, 0xB8,
			0x80, 0x78, 0x00, 0x00,
		};

		ret = findString(lSize, to_find_atsign, 12, 1) - 0x300;

		if (ret < 0) {
			print_ascdat_character(to_find_atsign);
			printf("** WARNING: Could not find the at sign in firmware font. It should look like the above symbol. asc.dat will be ignored. **\n");
		} else {
			printf("Opening asc.dat\n");
			char ascdata[1536];
			asc = fopen("asc.dat", "rb");
			if (asc == NULL) {
				printf("ERROR - could not open asc.dat. Skipping font replacement.\n");
			} else {
				size_t read = fread(ascdata, 1, 1536, asc);
				fclose(asc);
				if (read < 1536) {
					printf("ERROR - not enough bytes read from asc.dat. Skipping font replacement.\n");
				} else if (memcmp(to_find_atsign, ascdata + 0x300, 12) != 0) {
					print_ascdat_character(ascdata + 0x300);
					printf("ERROR - at sign not found in asc.dat. This might not be a valid font file. Skipping font replacement.\n");
				} else {
					printf("Old captial A:\n");
					print_ascdat_character(buf + ret + (12 * 'A'));
					memcpy(buf + ret, ascdata, 1536);
					printf("New captial A:\n");
					print_ascdat_character(buf + ret + (12 * 'A'));
				}
			}
		}

      // write the updater back to disk
        if ((inp = fopen(names[2], "wb")) == NULL)
        {
            printf("** Error re-opening ezfla_up.bin.\n");
            if (nds != NULL) fclose(nds);
            free(buf);
            return 0;
        }
        printf("Writing %s back to disk\n", names[2]);
        fwrite (buf, 1, lSize, inp);
    }
    else
    {

        if (( inp = fopen(names[2], "wb")) == NULL)
        {
            printf("** Error re-opening ezfla_up.bin.\n");
            fclose(nds);
            free(buf);
            return 0;
        }
      // write the updater back to disk less GBFS
        printf("Writing %s back to disk\n", names[2]);
        fwrite (buf, 1, ret, inp);
        printf("GBFS found at pos: 0x%lx (%ld)\nwriting new GBFS to disk\n", ret, ret);
      // write nds.bin to end of file
        while (count < lSizends)
        {
            tmp=getc(nds);
            putc(tmp, inp);
            count++;
        }
    }

    fclose(inp);
    fclose(gba);
	if (nds != NULL) fclose(nds);
    free(buf);

    printf("\n\nEZ4skin.exe Finished.\n");

    return 0;
}
